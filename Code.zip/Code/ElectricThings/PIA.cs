using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PIA : MonoBehaviour
{
    public bool open = true;
    public Transform rotPoint;
    public Vector3 OPEN;
    public Vector3 CLOSE;
    public Protection prot;
    public AudioSource pia_on;
    public AudioSource pia_off;
    public Diferencial diferencial;
    public bool trifasic = false;
    public ProtDup ProtDup;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(prot.sobrecarga==true)
        {
           if(open == false)
            {
                changeState();
            }
        }
        if(diferencial!= null)
        {
            if (diferencial.open == true)//diferencial abierto
            {
                prot.open = true;
            }
            else//diferencial cerrado
            {
                if (open == false)//PIA cerrado
                {
                    prot.open = false;
                }
                else
                {
                    prot.open = true;
                }
            }
        }
      
    }

    public void changeState()
    {
        if(open == true)
        {
            if(diferencial == null)
            {
                prot.open = false;
            }
            open = false;
            if(trifasic == true && ProtDup!=null)
            {
                ProtDup.rotPoint.localEulerAngles = CLOSE;
            }
            rotPoint.localEulerAngles = CLOSE;
            pia_on.Play();
            
        }else 
        if(open == false)
         {
            if (diferencial == null)
            {
                prot.open = true;
            }
            prot.open = true;
            open = true;
            if (trifasic == true && ProtDup != null)
            {
                ProtDup.rotPoint.localEulerAngles = OPEN;
            }
            rotPoint.localEulerAngles = OPEN;
            pia_off.Play();
         }
    }

    public void turnON()
    {
        if (open == true)
        {
            if(diferencial != null)
            {
                diferencial.turnON();
            }
            if (trifasic == true && ProtDup != null)
            {
                ProtDup.rotPoint.localEulerAngles = CLOSE;
            }
            prot.open = false;
            open = false;
            rotPoint.localEulerAngles = CLOSE;
        }
        else
        if (open == false)
        {

            //se queda encendido
        }
    }
}
