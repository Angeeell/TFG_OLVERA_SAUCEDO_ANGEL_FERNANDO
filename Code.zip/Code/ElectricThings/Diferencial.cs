using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Diferencial : MonoBehaviour
{

    public bool open = true;
    public Transform rotPoint;
    public Vector3 OPEN;
    public Vector3 CLOSE;
    public AudioSource pia_on;
    public AudioSource pia_off;
    public bool trifasic = false;
    public ProtDup ProtDup;
    // Start is called before the first frame update
    void Start()
    {
        turnOFF();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void changeState()
    {
        if (open == true)
        {
            open = false;
            pia_on.Play();
            if (trifasic == true && ProtDup != null)
            {
                ProtDup.rotPoint.localEulerAngles = CLOSE;
            }
            rotPoint.localEulerAngles = CLOSE;
        }
        else
        {
            open = true;
            pia_off.Play();
            if (trifasic == true && ProtDup != null)
            {
                ProtDup.rotPoint.localEulerAngles = OPEN;
            }
            rotPoint.localEulerAngles = OPEN; 
        }
    }
    public void turnON()
    {
        open = false;
        if (trifasic == true && ProtDup != null)
        {
            ProtDup.rotPoint.localEulerAngles = CLOSE;
        }
        rotPoint.localEulerAngles = CLOSE;
    }

    void turnOFF()
    {

        open = true;
        if (trifasic == true && ProtDup != null)
        {
            ProtDup.rotPoint.localEulerAngles = OPEN;
        }
        rotPoint.localEulerAngles = OPEN;
    }
}
