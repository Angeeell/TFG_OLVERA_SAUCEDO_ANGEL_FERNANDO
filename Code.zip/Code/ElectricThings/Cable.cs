using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class Cable : MonoBehaviour
{
    public bool activeSIM;
    ElectricalManager electricalManager;
    public float potencia_salida_verf;
    public float resistencia_Cable;
    public GameObject inicio;
    public GameObject final;
    Conexion conexion;
    public bool I_can = true;
    public float longitud = 1f;
    public float seccion = 4f;
    public float gamma = 44f;
    public float caida_tension;
    public float caida_tension_Voltios;
    public float perdidas_cable;
    public TextMeshPro tensionTX;
    public TextMeshPro intensidadTX;
    public TextMeshPro potenciaTX;
    public List<float> Tension = new List<float>();
    public List<float> Intensidad = new List<float>();
    public List<float> P_Cable = new List<float>();
    //tags 
    // ModuloFV   "MFV"
    // Inversor   "INV"
    // Proteccion "PROT"
    // Consumo    "CONS"
    // Cable      "CAB"
    // Start is called before the first frame update
    void Start()
    {
        conexion = GetComponent<Conexion>();
        conexion.final = final;
        electricalManager = FindObjectOfType<ElectricalManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(activeSIM == true)
        {
            resistencia_Cable = longitud / (gamma * seccion);//resistencia en ohmnios
            potencia_salida_verf = Tension[electricalManager.dato] * Intensidad[electricalManager.dato];
            float Tension_C = Tension[electricalManager.dato];//dato elegido por usuario
            tensionTX.text = "V: " + Tension_C.ToString("F1") + " V";//mostrar dato en pantalla
            float Intensidad_C = Intensidad[electricalManager.dato];//dato elegido por usuario
            intensidadTX.text = "I: " + Intensidad_C.ToString("F1") + " A";//mostrar dato en pantalla
            float Potencia_C = P_Cable[electricalManager.dato];//dato elegido por usuario
            potenciaTX.text = "P: " + (Potencia_C/1000).ToString("F1") + " kW";//mostrar dato en pantalla
        }
        #region de modulo FV a Proteccion
        if (inicio.tag =="MFV"&&activeSIM == true)//parte de un m�dulo fotovoltaico
        {
            if(final.tag == "PROT")//De un m�dulo a una proteccion
            {
                caida_tension_Voltios = inicio.GetComponent<FVmodule>().Vmp_Sistema[electricalManager.dato] - Tension[electricalManager.dato];
                caida_tension = caida_tension_Voltios * 100 / inicio.GetComponent<FVmodule>().Vmp_Sistema[electricalManager.dato];
                FVmodule FVmodule = inicio.GetComponent<FVmodule>();
                for(int i = 0; i < 24;  i++)
                {
                    if (Intensidad[electricalManager.dato]==0)//no se entrega potencia
                    {
                        Tension[i] = FVmodule.Vmp_Sistema[i];//se le asigna la tension al cable
                        Intensidad[i] = FVmodule.Imp_Sistema[i];//se le asigna la intensidad al cable
                        P_Cable[i] = FVmodule.P_Sistema[i] - Intensidad[i] * Intensidad[i] * resistencia_Cable;//potencia a la salida del cable teniendo en cuenta sus p�rdidas
                    }
                    else
                    {
                        Tension[i] = FVmodule.Vmp_Sistema[i] - Intensidad[i]* resistencia_Cable;//r equivalente de la longitud de ida y vuelta
                        Intensidad[i] = FVmodule.Imp_Sistema[i];//intensidad del sistema fotovoltaico
                        P_Cable[i] = FVmodule.P_Sistema[i] - Intensidad[i] * Intensidad[i] * resistencia_Cable;//por la R equivalente
                    }
                }
                Protection protection = final.GetComponent<Protection>();
                for (int i = 0; i < 24; i++)
                {
                    protection.Tension_E[i] = Tension[i];//se le asigna a la entrada de la proteccion la tension
                    protection.Intensidad_E[i] = Intensidad[i];//se le asigna a la entrada de la proteccion la intensidad
                    protection.P_PROT_E[i] = P_Cable[i];//se le asigna a la entrada de la proteccion la potencia a la salida del cable
                }
            }
        }
        #endregion

        if (inicio.tag == "PROT"&&activeSIM == true)//parte de una proteccion
        {
            if(final.tag == "INV")//a un Inversor (cable monof�sico)
            {
                caida_tension_Voltios = inicio.GetComponent<Protection>().Tension_S[electricalManager.dato] - Tension[electricalManager.dato];
                caida_tension = caida_tension_Voltios * 100 / inicio.GetComponent<Protection>().Tension_S[electricalManager.dato];
                Protection prote = inicio.GetComponent<Protection>();

                for (int i = 0; i < 24; i++)
                {
                    Intensidad[i] = prote.Intensidad_S[i];//se le asigna la intensidad al cable
                    if (Intensidad[i]>0)
                    {
                        Tension[i] = prote.Tension_S[i] - Intensidad[i] * resistencia_Cable;//se le asigna la tension al cable
                    }else
                    {
                        Tension[i] = prote.Tension_S[i];
                    }
                    
                   
                    P_Cable[i] = prote.P_PROT_S[i] - Intensidad[i] * Intensidad[i] * resistencia_Cable; ;//potencia a la salida del cable teniendo en cuenta sus p�rdidas
                    

                }
            }
            if(final.tag == "CONS")//al consumo (cable trif�sico)
            {
                caida_tension_Voltios = inicio.GetComponent<Protection>().Tension_S[electricalManager.dato] - Tension[electricalManager.dato];
                caida_tension = caida_tension_Voltios * 100 / inicio.GetComponent<Protection>().Tension_S[electricalManager.dato];
                Protection prote = inicio.GetComponent<Protection>();

                for (int i = 0; i < 24; i++)
                {
                    Intensidad[i] = prote.Intensidad_S[i];//se le asigna la intensidad al cable
                    if (Intensidad[i]>0)
                    {
                        Tension[i] = prote.Tension_S[i] - Mathf.Sqrt(3) * Intensidad[i] * resistencia_Cable;//se le asigna la tension al cable
                    }
                    else
                    {
                        Tension[i] = prote.Tension_S[i];//se le asigna la tension al cable
                    }
                    
                    
                    P_Cable[i] = prote.P_PROT_S[i] - Intensidad[i] * Intensidad[i] * 3 * resistencia_Cable; ;//potencia a la salida del cable teniendo en cuenta sus p�rdidas
                    

                }
            }
        }
        if (inicio.tag == "INV")//parte de un inversor
        {
            if(final.tag == "PROT")//a una proteccion (cable trif�sico)
            {

                Inversor inv = inicio.GetComponent<Inversor>();
                caida_tension_Voltios = inv.Tension_S[electricalManager.dato] - Tension[electricalManager.dato];
                caida_tension = caida_tension_Voltios * 100 / inv.Tension_S[electricalManager.dato];
                for (int i = 0; i < 24; i++)
                {
                    Intensidad[i] = inv.Intensidad_S[i];//se le asigna la intensidad al cable
                    if (Intensidad[i]>0)
                    {
                        Tension[i] = inv.Tension_S[i] - Mathf.Sqrt(3)*Intensidad[i] * resistencia_Cable;//se le asigna la tension al cable (trifasico)
                    }
                    else
                    {
                        Tension[i] = inv.Tension_S[i];//se le asigna la tension al cable
                    }
                   
                    
                    P_Cable[i] = inv.P_INV_S[i] - Intensidad[i] * Intensidad[i] * 3 * resistencia_Cable;//potencia a la salida del cable teniendo en cuenta sus p�rdidas
                    

                }
                Protection protection = final.GetComponent<Protection>();
                for (int i = 0; i < 24; i++)
                {
                    protection.Tension_E[i] = Tension[i];//se le asigna a la entrada de la proteccion la tension
                    protection.Intensidad_E[i] = Intensidad[i];//se le asigna a la entrada de la proteccion la intensidad
                    protection.P_PROT_E[i] = P_Cable[i];//se le asigna a la entrada de la proteccion la potencia a la salida del cable
                }
            }
        }
       

    }
}
