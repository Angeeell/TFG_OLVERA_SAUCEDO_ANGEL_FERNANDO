using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UIElements;

public class Inversor : MonoBehaviour
{
    public float rendimiento_INV_pu;
    public bool activeSIM;
    public bool circuitClosed;
    public bool tensionE1 = false;
    public bool tensionE2 = false;
    public float V_max;
    public float Vmp_max;
    public float Vmp_min;
    public float i_max_salida;
    public float i_max_E1;
    public float i_max_E2;
    public float i_actual_salida;
    public float i_actual_E1;
    public float i_actual_E2;
    public float coseno_FI =0.95f;
    ElectricalManager electricalManager;
    public GameObject cable_IN_1;
    public GameObject cable_IN_2;
    public GameObject final;
    public TextMeshPro V_E1TX;
    public TextMeshPro I_E1TX;
    public TextMeshPro P_E1TX;
    public TextMeshPro V_E2TX;
    public TextMeshPro I_E2TX;
    public TextMeshPro P_E2TX;
    public TextMeshPro V_STX;
    public TextMeshPro I_STX;
    public TextMeshPro P_STX;
    public List<float> Tension_E1 = new List<float>();
    public List<float> Intensidad_E1 = new List<float>();
    public List<float> P_INV_E1 = new List<float>();
    public List<float> Tension_E2 = new List<float>();
    public List<float> Intensidad_E2 = new List<float>();
    public List<float> P_INV_E2 = new List<float>();
    public List<float> Tension_S = new List<float>();
    public List<float> Intensidad_S = new List<float>();
    public List<float> P_INV_S = new List<float>();
    public List<GameObject> elementosAguasArriba = new List<GameObject>();
    Conexion conexion;
    // Start is called before the first frame update
    void Start()
    {
        conexion = GetComponent<Conexion>();
        conexion.final = final;
        electricalManager = FindObjectOfType<ElectricalManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(electricalManager.electSim == true)
        {
            i_actual_E1 = Intensidad_E1[electricalManager.dato];
            i_actual_E2 = Intensidad_E2[electricalManager.dato];
            i_actual_salida = Intensidad_S[electricalManager.dato];
            elementosAguasArriba.Clear();
            BuscarAguasArriba(final);
            GameObject[] array = elementosAguasArriba.ToArray();
            bool aux = true;
            for (int i = 0; i < elementosAguasArriba.Count; i++)
            {

                Protection prot = array[i].GetComponent<Protection>();
                if (prot != null)
                {

                    if (prot.open == true)
                    {
                        aux = false;

                    }
                }
                if (aux == true)
                {
                    circuitClosed = true;
                }
                else
                {
                    circuitClosed = false;
                }
            }
            #region output
            Cable cable_f = final.GetComponent<Cable>();
            
                //solo hay tension si se cierra el circuito
            if(circuitClosed == true)
            {
                for (int i = 0; i < 24; i++)
                {
                    Tension_S[i] = 400f;
                    
                    P_INV_S[i] = (P_INV_E1[i] + P_INV_E2[i])*rendimiento_INV_pu;
                    Intensidad_S[i] = P_INV_S[i] / (((float)Math.Sqrt(3)) * Tension_S[i]*coseno_FI);
                   
                }
            }else
            {
                for (int i = 0; i < 24; i++)
                {
                    Tension_S[i] = 0f;

                    P_INV_S[i] = 0f;
                    Intensidad_S[i] = 0f;
                }
            }
            #endregion
            #region texto de los datos
            if (activeSIM == true)
            {
                float V_E1 = Tension_E1[electricalManager.dato];//dato elegido por usuario
                V_E1TX.text = "V: " + V_E1.ToString("F1") + " V";//mostrar dato en pantalla
                float I_E1 = Intensidad_E1[electricalManager.dato];//dato elegido por usuario
                I_E1TX.text = "I: " + I_E1.ToString("F1") + " A";//mostrar dato en pantalla
                float P_E1 = P_INV_E1[electricalManager.dato];//dato elegido por usuario
                P_E1TX.text = "P: " + (P_E1/1000).ToString("F1") + " kW";//mostrar dato en pantalla

                float V_E2 = Tension_E2[electricalManager.dato];//dato elegido por usuario
                V_E2TX.text = "V: " + V_E2.ToString("F1") + " V";//mostrar dato en pantalla
                float I_E2 = Intensidad_E2[electricalManager.dato];//dato elegido por usuario
                I_E2TX.text = "I: " + I_E2.ToString("F1") + " A";//mostrar dato en pantalla
                float P_E2 = P_INV_E2[electricalManager.dato];//dato elegido por usuario
                P_E2TX.text = "P: " + (P_E2/1000).ToString("F1") + " kW";//mostrar dato en pantalla

                float V_S = Tension_S[electricalManager.dato];//dato elegido por usuario
                V_STX.text = "V: " + V_S.ToString("F1") + " V";//mostrar dato en pantalla
                float I_S = Intensidad_S[electricalManager.dato];//dato elegido por usuario
                I_STX.text = "I: " + I_S.ToString("F1") + " A";//mostrar dato en pantalla
                float P_S = P_INV_S[electricalManager.dato];//dato elegido por usuario
                P_STX.text = "P: " + (P_S/1000).ToString("F1") + " kW";//mostrar dato en pantalla

            }
            #endregion
            #region condiciones de entrada
            if (cable_IN_1.tag == "CAB")// de cable en entrada 1
            {
                if (final.tag == "CAB")// a cable en salida
                {
                    Cable cab1 = cable_IN_1.GetComponent<Cable>();
                    tensionE1 = true;
                    Tension_E1 = cab1.Tension;//igualamos tensiones
                    P_INV_E1 = cab1.P_Cable;//igualamos potencias
                    Intensidad_E1 = cab1.Intensidad;//igualamos intensidades

                    
                }
            }
            if (cable_IN_2.tag == "CAB")//de cable en entrada 2
            {
                if (final.tag == "CAB")// a cable en la salida
                {
                    Cable cab2 = cable_IN_2.GetComponent<Cable>();
                    tensionE2 = true;
                    Tension_E2 = cab2.Tension;//igualamos tensiones
                    P_INV_E2 = cab2.P_Cable;//igualamos potencias
                    Intensidad_E2 = cab2.Intensidad;//igualamos intensidades

                }
            }
            #endregion


            if (Tension_E1[electricalManager.dato] < Vmp_min || Tension_E1[electricalManager.dato]>Vmp_max)
            {
                //Debug.Log("Tension en la entrada 1 fuera de rango de m�xima potencia");
            }
            if (Tension_E2[electricalManager.dato] < Vmp_min || Tension_E2[electricalManager.dato] > Vmp_max)
            {
                //Debug.Log("Tension en la entrada 2 fuera de rango de m�xima potencia");
            }
            if(Tension_E1[electricalManager.dato]>V_max|| Tension_E2[electricalManager.dato] > V_max)
            {
                //Debug.Log("Tension peligrosa, mayor al limite maximo del inversor en el lado de DC");
            }
            if (Intensidad_S[electricalManager.dato] > i_max_salida)
            {
                Debug.Log("Valor de intensidad fuera de rando");
                //Limitar la potencia transferida
            }
        }
        else
        {
            i_actual_E1 = 0;
            i_actual_E2 = 0;
            i_actual_salida = 0;
        }








    }
    void BuscarAguasArriba(GameObject actual)
    {
        if (actual == null) return;

        elementosAguasArriba.Add(actual);

        if (actual.CompareTag("CONS"))
        {
            return; // Llegamos al final buscado
        }

        Conexion conexion = actual.GetComponent<Conexion>();
        if (conexion != null && conexion.final != null)
        {
            BuscarAguasArriba(conexion.final);
        }
    }
}
