using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using System;
public class FVmodule : MonoBehaviour
{
    public float G_min = 10f;
    public float diff_p;
    public bool activeSIM;
    public bool circuitClosed = false;
    public Radiation radiation;
    public GameObject elementoInicial; // Arr�stralo desde el inspector
    public List<GameObject> elementosAguasArriba = new List<GameObject>();
    public int Ns;
    public int Np;
    public float Ppico;
    public float Vmp;
    public float Voc;
    public float Imp;
    public float Isc;
    public float FF;
    public float gammaP;
    public float betaMP;
    public float betaOC;
    public float alfa_Isc;
    public float TNOC;
    public TextMeshPro tensionTX;
    public TextMeshPro intensidadTX;
    public TextMeshPro potenciaTX;
    public List<float> P_Sistema = new List<float>();
    public List<float> Vmp_Sistema = new List<float>();
    public List<float> Voc_Sistema = new List<float>();
    public List<float> Imp_Sistema = new List<float>();
    public List<float> T_celula_mod = new List<float>();
    ElectricalManager electricalManager;
    float k_boltz = 1.381f*Mathf.Pow(10, -23);
    float q_electron = 1.60218f * Mathf.Pow(10, -19);
    float n = 1.3f;

    //public List<float> Isc_Sistema = new List<float>();
    // Start is called before the first frame update
    void Start()
    {
        radiation = FindObjectOfType<Radiation>();
        electricalManager = FindObjectOfType<ElectricalManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(activeSIM == false)
        {
            P_Sistema = Enumerable.Repeat(0f, 24).ToList();
            Voc_Sistema = Enumerable.Repeat(0f, 24).ToList();
            Vmp_Sistema = Enumerable.Repeat(0f, 24).ToList();
            Imp_Sistema = Enumerable.Repeat(0f, 24).ToList();
            T_celula_mod = Enumerable.Repeat(0f, 24).ToList();
        }
        if(activeSIM == true)
        {
            UpdateSimState();
            //verificar ruta de conexion
            elementosAguasArriba.Clear();
            BuscarAguasArriba(elementoInicial);
            GameObject[] array = elementosAguasArriba.ToArray();
            bool aux = true;
            for (int i = 0; i< elementosAguasArriba.Count; i++)
            {
                
                Protection prot = array[i].GetComponent<Protection>();
                if (prot != null)
                {
                    
                    if (prot.open == true)
                    {
                        aux = false;
                        
                    }
                }
                if(aux == true)
                {
                    circuitClosed = true;
                }else
                {
                    circuitClosed = false;
                }
            }



            if(circuitClosed == false)
            {
                P_Sistema = Enumerable.Repeat(0f, 24).ToList();
                Imp_Sistema = Enumerable.Repeat(0f, 24).ToList();
            }

            float Tension = Vmp_Sistema[electricalManager.dato];//dato elegido por usuario
            tensionTX.text = "V: " + Tension.ToString("F1") + " V";//mostrar dato en pantalla
            float intensidad = Imp_Sistema[electricalManager.dato];//dato elegido por usuario
            intensidadTX.text = "I: " + intensidad.ToString("F1") + " A";//mostrar dato en pantalla
            float potencia = P_Sistema[electricalManager.dato];//dato elegido por usuario
            potenciaTX.text = "P: " + (potencia/1000).ToString("F1") + " kW";//mostrar dato en pantalla
        }

    }

    public void UpdateSimState()
    {
        for (int i = 0; i < 24; i++)
        {
            betaMP = betaOC * Vmp / Voc;//aproximaci�n lineal de la beta de maxima potencia, expresarlo en el documento(igual no es necesario)
            FF = Vmp * Imp / (Isc * Voc);//factor de forma

            float T_celula = radiation.T_amb_Actual[i] + (TNOC - 20) * radiation.G_i_Actual[i]/800f;//temperatura de celula
            T_celula_mod[i] = T_celula;
            float Ppico_corregida = Ppico * radiation.G_i_Actual[i] * (1 + gammaP * (T_celula - 25f) / 100f) / 1000f;//potencia de un modulo corregida por temperatura e irradiancia

            float V_mp_T = Vmp + betaMP * Vmp * (T_celula - 25) / 100;//tension MP por efecto de temperatura
            float V_mp_T_G = V_mp_T + n * k_boltz * (T_celula + 273.15f) / q_electron * Mathf.Log((radiation.G_i_Actual[i] + Mathf.Epsilon) / 1000);//tension MP por irradiancia y temperatura

            float V_oc_T = Voc + betaOC * Voc * (T_celula - 25) / 100;//tension OC por efecto de temperatura
            float V_oc_T_G = V_oc_T + n * k_boltz * (T_celula + 273.15f) / q_electron * Mathf.Log((radiation.G_i_Actual[i] + Mathf.Epsilon) / 1000);//tension por temp e irradiancia
            
            float I_mp = Imp*(1+alfa_Isc/100*(T_celula-25))*radiation.G_i_Actual[i]/1000;//calculo de IMP, considerando Alfa_Isc aprox Alfa_Imp
            float I_sc = Isc * (1 + alfa_Isc / 100 * (T_celula - 25)) * radiation.G_i_Actual[i] / 1000;

            //Debug.Log("Calculos comunes Momento: "+ (i+1) + "\nRadiacion: " + radiation.G_i_Actual[i] + 
              //  "\nT_celula: " + T_celula + "\nPpico corregida: " + Ppico_corregida + 
              //  "\nTension MP: " + V_mp_T_G + "\nTension OC: " + V_oc_T_G + "\nImp: " + I_mp + "\nIsc: " + I_sc +
              //  "\nFF: " + FF + "\nP por FF: " + (FF*I_sc*V_oc_T_G) + "\n diferencia Potencia: " + (Ppico_corregida - FF * I_sc * V_oc_T_G));

            if (circuitClosed==true&& radiation.G_i_Actual[i]>G_min)//asignacion de potencia
            {
                P_Sistema[i] = Ppico_corregida * Ns * Np;
            }else
            {
                P_Sistema[i] = 0f;
            }

            if (circuitClosed == true) //se trabaja en maxima potencia
            {
                float V_panel = 0;
                if (radiation.G_i_Actual[i] > G_min)//solo aplicar cuando sea mayor
                {
                    Imp_Sistema[i] = I_mp*Np;
                    V_panel = P_Sistema[i] / Imp_Sistema[i];
                }
                else
                {
                    Imp_Sistema[i] = 0;
                    V_panel = 0;
                }
                Vmp_Sistema[i] = V_panel;
            } 
            else //se trabaja en circuito abierto
            {
                Imp_Sistema[i] = 0;
                float V_panel = 0;
                if (radiation.G_i_Actual[i] > G_min)//solo aplicar cuando sea mayor
                { 
                    V_panel = V_oc_T_G * Ns; 
                }
                else
                {
                    V_panel = 0;
                }
                Vmp_Sistema[i] = V_panel;
            }
        }
    }
    void BuscarAguasArriba(GameObject actual)
    {
        if (actual == null) return;

        elementosAguasArriba.Add(actual);

        if (actual.CompareTag("CONS"))
        {
            return; // Llegamos al final buscado
        }

        Conexion conexion = actual.GetComponent<Conexion>();
        if (conexion != null && conexion.final != null)
        {
            BuscarAguasArriba(conexion.final);
        }
    }
}
