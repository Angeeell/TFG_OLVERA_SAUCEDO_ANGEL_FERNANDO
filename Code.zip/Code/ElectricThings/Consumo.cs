using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using System.IO;
using System.Linq;
using TMPro;
public class Consumo : MonoBehaviour
{
    ElectricalManager electricalManager;
    public List<float> Tension_CONS = new List<float>();
    public List<float> Intensidad_CONS = new List<float>();
    public List<float> P_CONS_FV = new List<float>();
    public List<float> P_CONS_INSTALACION_L = new List<float>();
    public List<float> P_CONS_INSTALACION_NL = new List<float>();
    public List<string> Hora_L = new List<string>();
    public List<string> Hora_NL = new List<string>();
    public GameObject[] cables;
    public TextMeshPro V_CTX;
    public TextMeshPro I_CTX;
    public TextMeshPro P_CTX;
    public TextMeshPro P_consumo_tx;
    public TextMeshPro P_Red_tx;
    // Start is called before the first frame update
    void Start()
    {
        electricalManager = FindObjectOfType<ElectricalManager>();
        //formato hora; consumo dia lectivo; consumo dia no lectivo
        #region consumos
        string Cons_I_L_FILE = Application.dataPath + "/Data/Consumo_I.csv";
        #region dia L
        if (File.Exists(Cons_I_L_FILE))
        {
            string[] lines = File.ReadAllLines(Cons_I_L_FILE);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float Consumo;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool G_i_ok = float.TryParse(values[1], NumberStyles.Float, culture, out Consumo);

                    if (G_i_ok)
                    {
                        Hora_L.Add(hora);
                        P_CONS_INSTALACION_L.Add(Consumo);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < Hora_L.Count; i++)
            {
                //Debug.Log($"Hora: {hora_SI[i]} - Elevaci�n: {alturaSolar_SI[i]} - Azimut: {azimut_SI[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + Cons_I_L_FILE);
        }
        #endregion
        #region dia NL
        if (File.Exists(Cons_I_L_FILE))
        {
            string[] lines = File.ReadAllLines(Cons_I_L_FILE);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float Consumo;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool G_i_ok = float.TryParse(values[2], NumberStyles.Float, culture, out Consumo);

                    if (G_i_ok)
                    {
                        Hora_NL.Add(hora);
                        P_CONS_INSTALACION_NL.Add(Consumo);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < Hora_NL.Count; i++)
            {
                //Debug.Log($"Hora: {hora_SI[i]} - Elevaci�n: {alturaSolar_SI[i]} - Azimut: {azimut_SI[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + Cons_I_L_FILE);
        }
        #endregion
        #endregion
        //Tension_CONS = Enumerable.Repeat(400f, 24).ToList();
    }

    // Update is called once per frame
    void Update()
    {
        Tension_CONS = cables[0].GetComponent<Cable>().Tension;//ajuste de un solo cable por entrada, para futuro hacer casos de varios cables al consumo, cogiendo el valor m�nimo de tension
        #region textos
        float V_E1 = Tension_CONS[electricalManager.dato];//dato elegido por usuario
        V_CTX.text = "V: " + V_E1.ToString("F1") + " V";//mostrar dato en pantalla
        float I_E1 = Intensidad_CONS[electricalManager.dato];//dato elegido por usuario
        I_CTX.text = "I: " + I_E1.ToString("F1") + " A";//mostrar dato en pantalla
        float P_E1 = P_CONS_FV[electricalManager.dato];//dato elegido por usuario
        P_CTX.text = "P_FV: " + (P_E1/1000).ToString("F1") + " kW";//mostrar dato en pantalla
        if(electricalManager.diaLectivo == true)
        {
            float cons_I_L = P_CONS_INSTALACION_L[electricalManager.dato];
            P_consumo_tx.text = "P_CONS: "+(cons_I_L).ToString("F1") + " kW";
            P_Red_tx.text = "P_RED: "+(P_CONS_FV[electricalManager.dato]/1000 - cons_I_L).ToString("F1")+ " kW";  
        }else
        {
            float cons_I_L = P_CONS_INSTALACION_NL[electricalManager.dato];
            P_consumo_tx.text = "P_CONS: " + (cons_I_L).ToString("F1") + " kW";
            P_Red_tx.text = "P_RED: " + (P_CONS_FV[electricalManager.dato]/1000 - cons_I_L).ToString("F1") + " kW";
        }
        #endregion

        
        for (int j = 0; j < 24; j++)//se le suman las potencias de los inputs
        {
               
                 float aux_P = 0;
                    for (int i = 0; i<cables.Length; i++)
                    {
                        Cable cab = cables[i].GetComponent<Cable>();
                         aux_P += cab.P_Cable[j];
                    }

            P_CONS_FV[j] = aux_P;


        }
        for (int j = 0; j < 24; j++)//se le suman las intensidades de los inputs
        {

            float aux_P = 0;
            for (int i = 0; i < cables.Length; i++)
            {
                Cable cab = cables[i].GetComponent<Cable>();
                aux_P += cab.Intensidad[j];
            }

            Intensidad_CONS[j] = aux_P;


        }

    }
}
