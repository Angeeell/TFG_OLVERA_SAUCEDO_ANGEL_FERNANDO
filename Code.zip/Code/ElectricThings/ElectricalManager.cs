using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectricalManager : MonoBehaviour
{
    Consumo consumo;
    public bool electSim = false;
    public Radiation radiation;
    public FVmodule[] modulos;
    public Cable[] cables;
    public Protection[] prots;
    public Inversor[] inversores;
    public int dato;
    public bool diaLectivo;
    public bool turnON_ALL_PIAS;
    public PIA[] pias;
    public float P_FV;
    public float P_FV_CONS;
    public float rendimiento_global;
    public float p_pico_all;
    public int ciclo_Vida;
    public float p_potencia_vida;
    public float perdidas_mismatch;
    public float perdidas_suciedad;
    public float perdidas_potencia;
    public float perdidas_temperatura;
    public float perdidas_cables_inversor;

    // Start is called before the first frame update
    void Start()
    {
        consumo = FindObjectOfType<Consumo>();
        pias = FindObjectsOfType<PIA>();
        radiation = FindObjectOfType<Radiation>();
        modulos = FindObjectsOfType<FVmodule>();
        cables = FindObjectsOfType<Cable>();
        prots = FindObjectsOfType<Protection>();
        inversores = FindObjectsOfType<Inversor>();
    }

    // Update is called once per frame
    void Update()
    {
      if(electSim == true)
      {
            float aux = 0;
            for(int i = 0; i < modulos.Length; i++)
            {
                modulos[i].Ppico = p_pico_all * Mathf.Pow((1 - p_potencia_vida), ciclo_Vida)*(1-perdidas_mismatch/100)*(1-perdidas_suciedad/100);
                aux += modulos[i].P_Sistema[dato];
            }
            P_FV = aux;
            P_FV_CONS = consumo.P_CONS_FV[dato];
            if(P_FV>0)
            {
                perdidas_cables_inversor = 100 - P_FV_CONS / P_FV*100;
                perdidas_temperatura = (modulos[0].gammaP/100 * (modulos[0].T_celula_mod[dato] - 25)*-1)*100;
                perdidas_potencia = (1-Mathf.Pow((1 - p_potencia_vida), ciclo_Vida))*100;
                rendimiento_global = 100-(perdidas_suciedad)-(perdidas_mismatch)-perdidas_potencia-perdidas_cables_inversor-perdidas_temperatura;
            }else
            {
                rendimiento_global = 0;
            }
            

            if(Input.GetKeyDown(KeyCode.P))//sumarle 1
            {
                if(dato < 23)
                {
                    dato = dato + 1;
                }
            }
            if(Input.GetKeyDown(KeyCode.O))//quitarle 1
            {
                if (dato > 0)
                {
                    dato = dato - 1;
                }
            }
      }

      if(turnON_ALL_PIAS == true)
        {
            for(int i = 0; i < pias.Length; i++)
            {
                pias[i].turnON();
            }
            turnON_ALL_PIAS = false;
        }
    }
    public void changeSimState(int state)
    {
        if (electSim == false)
        {
            radiation.simulacion = state;
            radiation.electSim = true;
            electSim = true;
           
        }
       

    }
    public void updateModules()
    {
        for (int i = 0; i < modulos.Length; i++)
        {
            
            modulos[i].activeSIM = true;
            modulos[i].UpdateSimState();
        }
        for (int i = 0;i < cables.Length; i++)
        {
            cables[i].activeSIM = true;
        }
        for (int i = 0; i < prots.Length; i++)
        {
            prots[i].activeSIM = true;
        }
        for (int i = 0; i < inversores.Length; i++)
        {
            inversores[i].activeSIM = true;
        }

    }
    public void ENDchangeSimState()
    {
        if (electSim == true)
        {
            radiation.electSim = false;
            electSim = false;
            for (int i = 0;i < modulos.Length;i++)
            {
                modulos[i].activeSIM = false;
            }
            for (int i = 0; i < cables.Length; i++)
            {
                cables[i].activeSIM = false;
            }
            for (int i = 0; i < prots.Length; i++)
            {
                prots[i].activeSIM = false;
            }
            for (int i = 0; i < inversores.Length; i++)
            {
                inversores[i].activeSIM = false;
            }
        }

    }
}
