using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Linq;
public class Protection : MonoBehaviour
{
    ElectricalManager electricalManager;
    public bool activeSIM;
    public bool open = true;//est� abierta la proteccion
    public GameObject inicio;
    public GameObject final;
    public bool isIga;
    public float i_nominal;
    public float i_actual;
    public GameObject[] PIAS;
    public TextMeshPro V_ETX;
    public TextMeshPro I_ETX;
    public TextMeshPro P_ETX;
    public TextMeshPro V_STX;
    public TextMeshPro I_STX;
    public TextMeshPro P_STX;
    public List<float> Tension_E = new List<float>();
    public List<float> Intensidad_E = new List<float>();
    public List<float> P_PROT_E = new List<float>();
    public List<float> Tension_S = new List<float>();
    public List<float> Intensidad_S = new List<float>();
    public List<float> P_PROT_S = new List<float>();
    Conexion conexion;
    int aux_pia_close;
    public bool sobrecarga;
    //tags 
    // ModuloFV   "MFV"
    // Inversor   "INV"
    // Proteccion "PROT"
    // Consumo    "CONS"
    // Cable      "CAB"
    // Start is called before the first frame update
    void Start()
    {
        conexion = GetComponent<Conexion>();
        conexion.final = final;
        electricalManager = FindObjectOfType<ElectricalManager>();
    }

    // Update is called once per frame
    void Update()
    {
        #region texto de los datos
        if (activeSIM == true)
        {
            i_actual = Intensidad_E[electricalManager.dato];
            if (i_actual > i_nominal*1.13f)
            {
                sobrecarga = true;
                Debug.Log("Sobrecarga en el interruptor: " + this.name + " Con valor: " + i_actual + " A");
            }else
            {
                sobrecarga=false;
            }
            float V_E = Tension_E[electricalManager.dato];//dato elegido por usuario
            V_ETX.text = "V: " + V_E.ToString("F1") + " V";//mostrar dato en pantalla
            float I_E = Intensidad_E[electricalManager.dato];//dato elegido por usuario
            I_ETX.text = "I: " + I_E.ToString("F1") + " A";//mostrar dato en pantalla
            float P_E = P_PROT_E[electricalManager.dato];//dato elegido por usuario
            P_ETX.text = "P: " + (P_E/1000).ToString("F1") + " kW";//mostrar dato en pantalla

            float V_S = Tension_S[electricalManager.dato];//dato elegido por usuario
            V_STX.text = "V: " + V_S.ToString("F1") + " V";//mostrar dato en pantalla
            float I_S = Intensidad_S[electricalManager.dato];//dato elegido por usuario
            I_STX.text = "I: " + I_S.ToString("F1") + " A";//mostrar dato en pantalla
            float P_S = P_PROT_S[electricalManager.dato];//dato elegido por usuario
            P_STX.text = "P: " + (P_S/1000).ToString("F1") + " kW";//mostrar dato en pantalla

        }
        else
        {
            i_actual = 0;
        }
        #endregion
        if (inicio.tag == "CAB")//parte de un cable
        {
            if (final.tag == "PROT")// va a una proteccion dentro del cuadro
            {
                
            }
           
        }
        if(inicio.tag=="PROT")//partimos de una proteccion
        {
            if(final.tag=="CAB")//hacia un cable
            {
                if(isIga == true)//Somos un IGA
                {

                    
                    for (int j = 0; j < 24; j++)//potencia a la salida del IGA
                    {
                        float aux = 0;
                        float aux2 = 0;
                        for (int i = 0; i<PIAS.Length;i++)
                        {
                            aux += PIAS[i].GetComponent<Protection>().P_PROT_E[j];
                            aux2 += PIAS[i].GetComponent<Protection>().Intensidad_E[j];
                        }
                        P_PROT_E[j] = aux;
                        Intensidad_E[j] = aux2;
                    }

                    #region verificar si hay al menos un Pia Cerrado
                    bool PIA_cerrado = false;
                    for (int i = 0; i < PIAS.Length; i++)
                    {
                        Protection prot = PIAS[i].GetComponent<Protection>();

                        if (prot.open == false)
                        {
                            aux_pia_close = i;
                            PIA_cerrado = true;//si hay al menos un PIA cerrado ya se vuelve true
                            break;
                        }
                    }
                    #endregion

                    if (open == true)//IGA abierto,, solo se juega con las tensiones
                    {
                        Tension_S = Enumerable.Repeat(0f, 24).ToList();
                        //no hay ningun PIA cerrado
                        if (PIA_cerrado == false)//no hay PIA cerrado y el IGA est� abierto
                        {
                            for(int i = 0;i < PIAS.Length;i++)
                            {
                                Protection prot = PIAS[i].GetComponent<Protection>();
                                prot.Tension_S = Enumerable.Repeat(0f, 24).ToList();
                                Tension_E = Enumerable.Repeat(0f, 24).ToList();
                            }
                        }else//hay al menos 1 PIA cerrado y el IGA est� abierto
                        {
                            Protection prot = PIAS[aux_pia_close].GetComponent<Protection>();
                            Tension_E = prot.Tension_E;//tension del IGA a la tension de ese PIA
                            for (int i = 0; i < PIAS.Length; i++)
                            {
                                Protection prote = PIAS[i].GetComponent<Protection>();
                                prote.Tension_S = Tension_E;//tension de los PIAS a su salida a la nueva tension
                            }
                        }
                    }else//IGA cerrado
                    {
                        //no hay ningun PIA cerrado
                        if (PIA_cerrado == false)//no hay PIA cerrado y el IGA est� cerrado
                        {
                            for (int i = 0; i < PIAS.Length; i++)
                            {
                                Protection prot = PIAS[i].GetComponent<Protection>();
                                prot.Tension_S = Enumerable.Repeat(0f, 24).ToList();
                                Tension_E = Enumerable.Repeat(0f, 24).ToList();
                                prot.Intensidad_S = Enumerable.Repeat(0f, 24).ToList();
                                prot.P_PROT_S = Enumerable.Repeat(0f, 24).ToList();
                            }
                        }
                        else//hay al menos 1 PIA cerrado y el IGA est� cerrado
                        {
                            Protection prot = PIAS[aux_pia_close].GetComponent<Protection>();
                            Tension_E = prot.Tension_E;//tension del IGA a la tension de ese PIA
                            for (int i = 0; i < PIAS.Length; i++)
                            {
                                Protection prote = PIAS[i].GetComponent<Protection>();
                                prote.Tension_S = Tension_E;//tension de los PIAS a su salida a la nueva tension
                                prote.P_PROT_S = prote.P_PROT_E;
                                prote.Intensidad_S = prote.Intensidad_E;
                            }
                        }
                        Tension_S = Tension_E;
                        Intensidad_S = Intensidad_E;
                        P_PROT_S = P_PROT_E; ;
                    }
                   
                }
            }
        }
        
            
        
    }
}
