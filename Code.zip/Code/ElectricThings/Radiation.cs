using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using System.IO;
using System.Linq;
public class Radiation : MonoBehaviour
{
    public List<float> G_i_L = new List<float>();
    public List<float> T_amb_L = new List<float>();
    public List<string> hora_L = new List<string>();
    public int simulacion;
    public List<float> G_i_NL = new List<float>();
    public List<float> T_amb_NL = new List<float>();
    public List<string> hora_NL = new List<string>();
    //0-Lectivo
    //1-No Lectivo
    public List<float> G_i_Actual = new List<float>();
    public List<float> T_amb_Actual = new List<float>();
    public List<string> hora_Actual = new List<string>();
    public bool electSim = false;
    public ElectricalManager electricalManager;
    // Start is called before the first frame update
    void Start()
    {
        #region diaLectivo_Radiation
        string Radiation_File = Application.dataPath + "/Data/Radiation_L.csv";

            if (File.Exists(Radiation_File))
            {
                string[] lines = File.ReadAllLines(Radiation_File);
                CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

                // Saltamos la cabecera
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] values = line.Split(';'); // Cambiado a punto y coma

                    if (values.Length >= 3)
                    {
                        string hora = values[0];
                        float G_i;
                        float T_amb;

                        // Intentamos convertir Elevacion y Azimut a float con formato seguro
                        bool G_i_ok = float.TryParse(values[1], NumberStyles.Float, culture, out G_i);
                        bool T_amb_ok = float.TryParse(values[2], NumberStyles.Float, culture, out T_amb);

                        if (G_i_ok && T_amb_ok)
                        {
                            hora_L.Add(hora);
                            G_i_L.Add(G_i);
                            this.T_amb_L.Add(T_amb);
                        }
                        else
                        {
                            Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                        }
                    }
                    else
                    {
                        Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                    }
                }

                // Verificaci�n de que los datos se cargaron correctamente
                for (int i = 0; i < hora_L.Count; i++)
                {
                    //Debug.Log($"Hora: {hora_SI[i]} - Elevaci�n: {alturaSolar_SI[i]} - Azimut: {azimut_SI[i]}");
                }
            }
            else
            {
                Debug.LogError("Archivo CSV no encontrado en: " + Radiation_File);
            }
        #endregion
        #region diaNoLectivo_Radiation
        string Radiation_File_NL = Application.dataPath + "/Data/Radiation_A.csv";

        if (File.Exists(Radiation_File_NL))
        {
            string[] lines = File.ReadAllLines(Radiation_File_NL);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float G_i;
                    float T_amb;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool G_i_ok = float.TryParse(values[1], NumberStyles.Float, culture, out G_i);
                    bool T_amb_ok = float.TryParse(values[2], NumberStyles.Float, culture, out T_amb);

                    if (G_i_ok && T_amb_ok)
                    {
                        hora_NL.Add(hora);
                        G_i_NL.Add(G_i);
                        this.T_amb_NL.Add(T_amb);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < hora_L.Count; i++)
            {
                //Debug.Log($"Hora: {hora_SI[i]} - Elevaci�n: {alturaSolar_SI[i]} - Azimut: {azimut_SI[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + Radiation_File);
        }
        #endregion
        electricalManager = FindObjectOfType<ElectricalManager>();
    }

    // Update is called once per frame
    void Update()
    {
       if(electSim == true)
       {
            if(simulacion == 0)//dia lectivo
            {
                G_i_Actual = G_i_L;
                T_amb_Actual = T_amb_L;
                hora_Actual = hora_L;
                electricalManager.updateModules();
                electricalManager.diaLectivo = true;
            }
            if(simulacion == 1)//dia no lectivo
            {
                G_i_Actual = G_i_NL;
                T_amb_Actual = T_amb_NL;
                hora_Actual = hora_NL;
                electricalManager.updateModules();
                electricalManager.diaLectivo = false;
            }
       }
       if(electSim == false)
       {
            G_i_Actual = Enumerable.Repeat(0f, 24).ToList();
            T_amb_Actual = Enumerable.Repeat(0f, 24).ToList();
       
       }
    }

}
