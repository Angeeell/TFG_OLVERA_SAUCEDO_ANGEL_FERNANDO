using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class FVGEN_VS_CONSUMO : MonoBehaviour
{
    public Consumo consumo;
    ElectricalManager electricalManager;
    public List<float> Tension_CONS = new List<float>();
    public List<float> Intensidad_CONS = new List<float>();
    public List<float> P_CONS_FV = new List<float>();
    public List<float> P_CONS_INSTALACION_L = new List<float>();
    public List<float> P_CONS_INSTALACION_NL = new List<float>();
    public List<string> Hora_L = new List<string>();
    public List<string> Hora_NL = new List<string>();
    public List<GameObject> ejeHora = new List<GameObject>();
    public GameObject tx_hora_prefab;
    public GameObject tx_potencia_prefab;
    public GameObject punto_potencia_cero;
    public GameObject hora_seleccionada;
    public Vector3 offSet_hora_seleccionada;
    public float P_max_graf;
    public Transform[] puntos_CONS; //puntos de gen fv
    public Transform[] puntos_GEN_FV;// puntos del consumo
    private LineRenderer lineRenderer;
    public LineRenderer lineRenderer_FV;
    // Start is called before the first frame update
    void Start()
    {

        consumo = FindObjectOfType<Consumo>();
        electricalManager = FindObjectOfType<ElectricalManager>();

        // Obt�n el componente LineRenderer
        lineRenderer = GetComponent<LineRenderer>();

        // Establece la cantidad de puntos
        lineRenderer.positionCount = puntos_CONS.Length;
        lineRenderer_FV.positionCount = puntos_GEN_FV.Length;

        //generar los tx visuales de las horas en el eje X
        for (int i = 0; i < ejeHora.Count; i++)
        {
            GameObject hora_obj = Instantiate(tx_hora_prefab, ejeHora[i].transform);
            hora_obj.transform.parent = ejeHora[i].transform;
            hora_obj.transform.localPosition = new Vector3(0, 0, -0.12f);
            hora_obj.transform.localEulerAngles = new Vector3(90, 0, 0);
            hora_obj.GetComponentInChildren<TextMeshPro>().text = ejeHora[i].name;

        }
        float aux = 0;
        for(int i = 0; i< 7; i++)
        {
            aux += 5;
            GameObject potencia_obj = Instantiate(tx_potencia_prefab, punto_potencia_cero.transform);
            potencia_obj.transform.parent = punto_potencia_cero.transform.transform.parent;
            potencia_obj.transform.localScale = punto_potencia_cero.transform.localScale;
            potencia_obj.transform.localEulerAngles = new Vector3(90, 0, 0);
            potencia_obj.transform.localPosition = new Vector3(punto_potencia_cero.transform.localPosition.x , 0, punto_potencia_cero.transform.localPosition.z + aux*8f/P_max_graf);
            potencia_obj.GetComponentInChildren<TextMeshPro>().text = aux + " kW";
        }

        
    }

    // Update is called once per frame
    void Update()
    {
        Tension_CONS = consumo.Tension_CONS;
        Intensidad_CONS = consumo.Intensidad_CONS;
        P_CONS_FV = consumo.P_CONS_FV;
        P_CONS_INSTALACION_L = consumo.P_CONS_INSTALACION_L;
        P_CONS_INSTALACION_NL = consumo.P_CONS_INSTALACION_NL;
        Hora_L = consumo.Hora_L;
        Hora_NL = consumo.Hora_NL;
        if(electricalManager.electSim == true)
        {
            hora_seleccionada.transform.localPosition = ejeHora[electricalManager.dato].transform.localPosition + offSet_hora_seleccionada;
        }
        for (int i = 0; i < puntos_CONS.Length; i++)//aplicar la escala a los objetos
        {
            if(electricalManager.electSim == true)
            {
                
                puntos_GEN_FV[i].localPosition = new Vector3(puntos_GEN_FV[i].localPosition.x, 0, 1f + P_CONS_FV[i] * 8f / (P_max_graf*1000));
                if (electricalManager.diaLectivo == true)
                {
                    puntos_CONS[i].localPosition = new Vector3(puntos_CONS[i].localPosition.x, 0, 1f + P_CONS_INSTALACION_L[i] * 8f / P_max_graf);
                }
                else
                {
                    puntos_CONS[i].localPosition = new Vector3(puntos_CONS[i].localPosition.x, 0, 1f + P_CONS_INSTALACION_NL[i] * 8f / P_max_graf);
                }
            }
           
            
        }
        // Opcional: Si los puntos se mueven y quieres que la l�nea se actualice:
        for (int i = 0; i < puntos_CONS.Length; i++)
        {
            if(electricalManager.electSim == true)
            {
                lineRenderer.enabled = true;
                lineRenderer_FV.enabled = true;
                lineRenderer.SetPosition(i, puntos_CONS[i].position);
                lineRenderer_FV.SetPosition(i, puntos_GEN_FV[i].position);
            }
            else
            {
                lineRenderer.enabled = false;
                lineRenderer_FV.enabled = false;
            }
            
        }
    }
}
