using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Inversor_HMI : MonoBehaviour
{
    ElectricalManager electricalManager;
    public Inversor inversor;
    public Color off_C;
    public Color VE1_ON;
    public Color VE2_ON;
    public Color VS_ON;
    public Color PE1_ON;
    public Color PE2_ON;
    public Color PS_ON;
    public Color actual_VE1;
    public Color actual_VE2;
    public Color actual_VS;
    public Color actual_PE1;
    public Color actual_PE2;
    public Color actual_PS;
    public GameObject indicador_VE1;
    public GameObject indicador_VE2;
    public GameObject indicador_VS;
    public GameObject indicador_PE1;
    public GameObject indicador_PE2;
    public GameObject indicador_PS;
    public TextMeshPro inv_name_tx;
    public float t_ON;
    public float t_OFF;
    public bool bucle = false;
    // Start is called before the first frame update
    void Start()
    {
        electricalManager = FindObjectOfType<ElectricalManager>();
        inversor = this.GetComponent<Inversor>();
        inv_name_tx.text = inversor.name;
    }

    // Update is called once per frame
    void Update()
    {
        if (electricalManager.electSim == true)
        {
            if (inversor.Tension_E1[electricalManager.dato]>0)//hay tension en la entrada 1
            {
                actual_VE1 = VE1_ON;
            }else
            {
                actual_VE1 = off_C;
            }
            if (inversor.Tension_E2[electricalManager.dato] > 0)//hay tension en la entrada 2
            {
                actual_VE2 = VE2_ON;
            }
            else
            {
                actual_VE2 = off_C;
            }
            if (inversor.Tension_S[electricalManager.dato] > 0)//hay tension en la Salida 
            {
                actual_VS = VS_ON;
            }
            else
            {
                actual_VS = off_C;
            }
            if (inversor.P_INV_E1[electricalManager.dato] > 0)//hay potencia en la entrada 1
            {
                actual_PE1= PE1_ON;
            }
            else
            {
                actual_PE1 = off_C;
            }
            if (inversor.P_INV_E2[electricalManager.dato] > 0)//hay potencia en la entrada 2
            {
                actual_PE2 = PE2_ON;
            }
            else
            {
                actual_PE2 = off_C;
            }
            if (inversor.P_INV_S[electricalManager.dato] > 0)//hay potencia en la salida
            {
                actual_PS = PS_ON;
            }
            else
            {
                actual_PS = off_C;
            }

            if (bucle == false)
            {
                StartCoroutine(ciclo_ON_OFF(t_ON, t_OFF));
                bucle = true;
            }
        }



    }

    IEnumerator ciclo_ON_OFF(float ton, float toff)
    {
        indicador_VE1.GetComponent<Renderer>().material.color = actual_VE1;
        indicador_VE2.GetComponent<Renderer>().material.color = actual_VE2;
        indicador_VS.GetComponent<Renderer>().material.color = actual_VS;

        indicador_PE1.GetComponent<Renderer>().material.color = actual_PE1;
        indicador_PE2.GetComponent<Renderer>().material.color = actual_PE2;
        indicador_PS.GetComponent<Renderer>().material.color = actual_PS;
        yield return new WaitForSeconds(ton);
        indicador_VE1.GetComponent<Renderer>().material.color = off_C;
        indicador_VE2.GetComponent<Renderer>().material.color = off_C;
        indicador_VS.GetComponent<Renderer>().material.color = off_C;

        indicador_PE1.GetComponent<Renderer>().material.color = off_C;
        indicador_PE2.GetComponent<Renderer>().material.color = off_C;
        indicador_PS.GetComponent<Renderer>().material.color = off_C;
        yield return new WaitForSeconds(toff);
        bucle = false;
    }
}
