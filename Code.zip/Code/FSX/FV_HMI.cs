using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class FV_HMI : MonoBehaviour
{
    ElectricalManager electricalManager;
    public FVmodule fvModule;
    public Color off_C;
    public Color potencia_S;
    public Color No_Potencia_S;
    public Color actual_State_C;
    public GameObject indicador_Salida_Potencia;
    public TextMeshPro name_FV;
    public float t_ON;
    public float t_OFF;
    public bool bucle = false;
    // Start is called before the first frame update
    void Start()
    {
        electricalManager = FindObjectOfType<ElectricalManager>();
        fvModule = this.GetComponent<FVmodule>();
        name_FV.text = fvModule.name;
    }

    // Update is called once per frame
    void Update()
    {
        if(electricalManager.electSim == true)
        {
            if (fvModule.P_Sistema[electricalManager.dato] > 0)
            {
                actual_State_C = potencia_S;
            }else
            {
                actual_State_C = No_Potencia_S;
            }



            if (bucle == false)
            {
                StartCoroutine(ciclo_ON_OFF(t_ON, t_OFF));
                bucle = true;
            }
        }
        
       

    }

    IEnumerator ciclo_ON_OFF(float ton, float toff)
    {
        indicador_Salida_Potencia.GetComponent<Renderer>().material.color = actual_State_C;
        yield return new WaitForSeconds(ton);
        indicador_Salida_Potencia.GetComponent<Renderer>().material.color = off_C;
        yield return new WaitForSeconds(toff);
        bucle = false;
    }
}
