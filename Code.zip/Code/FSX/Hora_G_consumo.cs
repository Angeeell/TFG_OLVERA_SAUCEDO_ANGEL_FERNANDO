using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Hora_G_consumo : MonoBehaviour
{
    public TextMeshPro horatx;
    // Start is called before the first frame update
    void Start()
    {
        horatx = this.GetComponentInChildren<TextMeshPro>();
        horatx.text = this.gameObject.name;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
