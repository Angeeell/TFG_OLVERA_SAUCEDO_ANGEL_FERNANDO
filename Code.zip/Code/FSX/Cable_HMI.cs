using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Cable_HMI : MonoBehaviour
{
    ElectricalManager electricalManager;
    public Cable cable;
    public Color off_C;
    public Color tension_ON;
    public Color Potencia_ON;
    public Color actual_State_Tension;
    public Color actual_State_Potencia;
    public GameObject indicador_Tension;
    public GameObject indicador_Potencia;
    public TextMeshPro name_Ctx;
    public float t_ON;
    public float t_OFF;
    public bool bucle = false;
    // Start is called before the first frame update
    void Start()
    {
        electricalManager = FindObjectOfType<ElectricalManager>();
        cable = this.GetComponent<Cable>();
        name_Ctx.text = cable.name;
    }

    // Update is called once per frame
    void Update()
    {
        if (electricalManager.electSim == true)
        {

            if (cable.Tension[electricalManager.dato]>0)
            {
                actual_State_Tension = tension_ON;
            }else
            {
                actual_State_Tension = off_C;
            }
            if (cable.P_Cable[electricalManager.dato] > 0)
            {
                actual_State_Potencia = Potencia_ON;
            }
            else
            {
                actual_State_Potencia = off_C;
            }

            if (bucle == false)
            {
                StartCoroutine(ciclo_ON_OFF(t_ON, t_OFF));
                bucle = true;
            }
        }



    }

    IEnumerator ciclo_ON_OFF(float ton, float toff)
    {
        indicador_Tension.GetComponent<Renderer>().material.color = actual_State_Tension;
        indicador_Potencia.GetComponent<Renderer>().material.color = actual_State_Potencia;
        yield return new WaitForSeconds(ton);
        indicador_Tension.GetComponent<Renderer>().material.color = off_C;
        indicador_Potencia.GetComponent<Renderer>().material.color = off_C;
        yield return new WaitForSeconds(toff);
        bucle = false;
    }
}
