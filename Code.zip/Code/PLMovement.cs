using UnityEngine;

public class EditorStyleCamera : MonoBehaviour
{
    public float moveSpeed = 10f; // Velocidad de movimiento
    public float boostMultiplier = 2f; // Multiplicador para acelerar (Shift)
    public float rotationSpeed = 3f; // Sensibilidad del mouse
    Camera cam;
    private Vector3 lastMousePosition;
    private void Start()
    {
        cam = Camera.main;
    }
    void Update()
    {
        HandleMouseRotation();
        HandleMovement();
        if (Input.GetMouseButtonDown(0)) // Click izquierdo
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            
            if (Physics.Raycast(ray, out hit))
            {
                //Debug.Log(hit.transform.gameObject.name);
                PIA pia = hit.transform.GetComponent<PIA>();
                Diferencial dif = hit.transform.GetComponent<Diferencial>();
                if (pia!= null)
                {
                    
                    pia.changeState();
                }
                if(dif!= null)
                {
                    dif.changeState();
                }
            }
        }
    }

    void HandleMouseRotation()
    {
        if (Input.GetMouseButton(1)) // Bot�n derecho del rat�n
        {
            Vector3 mouseDelta = Input.mousePosition - lastMousePosition;

            float rotationX = mouseDelta.y * rotationSpeed * Time.deltaTime;
            float rotationY = mouseDelta.x * rotationSpeed * Time.deltaTime;

            transform.Rotate(Vector3.right, -rotationX, Space.Self);
            transform.Rotate(Vector3.up, rotationY, Space.World);
        }

        lastMousePosition = Input.mousePosition;
    }

    void HandleMovement()
    {
        Vector3 direction = Vector3.zero;

        if (Input.GetKey(KeyCode.W)) direction += transform.forward;
        if (Input.GetKey(KeyCode.S)) direction -= transform.forward;
        if (Input.GetKey(KeyCode.A)) direction -= transform.right;
        if (Input.GetKey(KeyCode.D)) direction += transform.right;
        if (Input.GetKey(KeyCode.Q)) direction -= transform.up;
        if (Input.GetKey(KeyCode.E)) direction += transform.up;

        float speed = Input.GetKey(KeyCode.LeftShift) ? moveSpeed * boostMultiplier : moveSpeed;

        transform.position += direction * speed * Time.deltaTime;
    }
}
