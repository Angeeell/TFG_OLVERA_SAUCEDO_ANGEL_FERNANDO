using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModulosFV3DManager : MonoBehaviour
{
    public ForcePanel []forcePanel;
    public bool aplicarFuerza;
    public bool progresiva;
    public bool rafaga;
    public float t_rafaga;
    public float fuerza;
    public float velocidad_km_h;
    public float densidad_aire = 1.225f;
    public float area_Modulo;
    public float inclinacion;
    public float escalador_Vector;
    public float escalador_velocidad;
    public Transform obj_ref;
    public float limitLog = 1000;
    public float ref_pos_i;
    public float dif_y;
    public float timer;
    // Start is called before the first frame update
    void Start()
    {
       forcePanel = FindObjectsOfType<ForcePanel>();
        ref_pos_i = obj_ref.transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        dif_y = obj_ref.transform.position.y - ref_pos_i;
        if (progresiva == true && rafaga == true)
        {
            Debug.LogWarning("No se pueden simular a la vez carga progresiva y r�faga de viento");
        }
        if (aplicarFuerza==true&&dif_y<0.05f&&progresiva==true&&rafaga==false)
        {
            velocidad_km_h += escalador_velocidad;
            float v = velocidad_km_h * 1000 / 3600;
            fuerza = 0.5f * densidad_aire * Mathf.Pow(v, 2) * area_Modulo * Mathf.Sin(Mathf.PI*inclinacion/180);
            for (int i = 0; i < forcePanel.Length; i++)
            {
                forcePanel[i].applyforce = true;
                forcePanel[i].force = fuerza;
                
            }
            
        }
        if(rafaga == true && progresiva == false && aplicarFuerza==true)
        {
            timer += Time.deltaTime;
            if(timer<t_rafaga)//simular fuerza
            {
                float v = velocidad_km_h * 1000 / 3600;
                fuerza = 0.5f * densidad_aire * Mathf.Pow(v, 2) * area_Modulo * Mathf.Sin(Mathf.PI * inclinacion / 180);
                for (int i = 0; i < forcePanel.Length; i++)
                {
                    forcePanel[i].applyforce = true;
                    forcePanel[i].force = fuerza;

                }
            }
            if(timer>t_rafaga)
            {
                for (int i = 0; i < forcePanel.Length; i++)
                {
                    forcePanel[i].applyforce = false;
                    forcePanel[i].force = 0;

                }
                rafaga = false;
                aplicarFuerza = false;
                timer = 0;
            }
        }
       
    }


}
