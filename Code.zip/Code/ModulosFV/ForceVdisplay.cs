using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;

public class ForceVdisplay : MonoBehaviour
{
    public float pesoPanel;
    public float lastreTrasero;
    public float lastreDelantero;
    public float Fviento;
    public float pesoSOPSUP;
    public float pesoSOPINF;
    public Transform centroDeMomentos; 
    public Transform startPointPesoPanel;//
    public Transform endPointPesoPanel;//
    public Transform startLastreTrasero;//
    public Transform endLastreTrasero;//
    public Transform startLastreDelantero;//
    public Transform endLastreDelantero;//
    public Transform startFviento;//
    public Transform endFviento;//
    public Transform startSoporteSUP;
    public Transform endSoporteSUP;
    public Transform startSoporteINF;
    public Transform endSoporteINF;
    public Transform momentosSTNeg;
    public Transform momentosSTPos;
    public Transform momentoPositivoEND;
    public Transform momentoNegativoEND;
    public ModulosFV3DManager manager;
    public float scale;
    public float momentoPositivo;
    public float momentoNegativo;
    public float distanciaAFviento;
    public float distanciaPesoPanel;
    public float distancialastreTrasero;
    public float distancialastreDelantero;
    public float distanciaSoporteSUP;
    public float distanciaSoporteINF;
    // Start is called before the first frame update
    void Start()
    {
        manager = FindObjectOfType<ModulosFV3DManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(centroDeMomentos != null && manager != null)
        {//----------------------------------------Representaci�n vectores Fuerza-------------------------------------------------------------------------------------------------//
            //peso del panel
            endPointPesoPanel.position = new Vector3(startPointPesoPanel.position.x, startPointPesoPanel.position.y - pesoPanel*9.81f*scale, startPointPesoPanel.position.z);
            //peso lastre trasero
            endLastreTrasero.position = new Vector3(startLastreTrasero.position.x, startLastreTrasero.position.y - lastreTrasero * 9.81f * scale, startLastreTrasero.position.z);
            //peso lastre delantero
            endLastreDelantero.position = new Vector3(startLastreDelantero.position.x, startLastreDelantero.position.y - lastreDelantero * 9.81f * scale, startLastreDelantero.position.z);
            //Fviento
            endFviento.position = new Vector3(startFviento.position.x, startFviento.position.y, startFviento.position.z - manager.fuerza*scale*6);
            //Fsoporte superior
            endSoporteSUP.position = new Vector3(startSoporteSUP.position.x, startSoporteSUP.position.y - pesoSOPSUP * 9.81f * scale, startSoporteSUP.position.z);
            //Fsoporte inferior
            endSoporteINF.position = new Vector3(startSoporteINF.position.x, startSoporteINF.position.y - pesoSOPINF * 9.81f * scale, startSoporteINF.position.z);
            //-------------------------------------c�lculo de momento positivo-----------------------------------------------------------------------------------------------------//
            distanciaAFviento = startFviento.position.y - centroDeMomentos.position.y;
            momentoPositivo = distanciaAFviento * manager.fuerza * 6;
            //-------------------------------------c�lculo de momento negativo-----------------------------------------------------------------------------------------------------//
            //peso de panel
            distanciaPesoPanel = startPointPesoPanel.position.z - centroDeMomentos.position.z;
            //lastre delantero
            distancialastreTrasero = startLastreTrasero.position.z - centroDeMomentos.position.z;
            //lastre trasero
            distancialastreDelantero = startLastreDelantero.position.z - centroDeMomentos.position.z;
            //distancia SOP SUP
            distanciaSoporteSUP = startSoporteSUP.position.z - centroDeMomentos.position.z;
            //distancia SOP INF
            distanciaSoporteINF = startSoporteINF.position.z - centroDeMomentos.position.z;
            //--------------------------------------momento neagtivo resultante----------------------------------------------------------------------------------------------------//
            momentoNegativo = distanciaPesoPanel * pesoPanel * 9.81f + distancialastreTrasero * lastreTrasero * 9.81f + distancialastreDelantero * lastreDelantero * 9.81f + distanciaSoporteSUP * pesoSOPSUP * 9.81f + distanciaSoporteINF * pesoSOPINF * 9.81f;
            //--------------------------------------resumen de momentos visual----------------------------------------------------------------------------------------------------//
            momentoNegativoEND.position = new Vector3(momentosSTNeg.position.x, momentosSTNeg.position.y + momentoNegativo * scale * 0.5f, momentosSTNeg.position.z);
            momentoPositivoEND.position = new Vector3(momentosSTPos.position.x, momentosSTPos.position.y + momentoPositivo * scale * 0.5f, momentosSTPos.position.z);
        }
    }

    private void OnDrawGizmos()
    {
        //esto es para hacer solo la representaci�n de lo que ocurre en la realidad
        #region 2dLine
        //if (startPointPesoPanel != null && endPointPesoPanel != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(startPointPesoPanel.position, endPointPesoPanel.position);
        //}
        //if (startFviento != null && endFviento != null)
        //{
        //    Gizmos.color = Color.green;
        //    Gizmos.DrawLine(startFviento.position, endFviento.position);
        //}
        //if (startLastreTrasero != null && endLastreTrasero != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(startLastreTrasero.position, endLastreTrasero.position);
        //}
        //if (startLastreDelantero != null && endLastreDelantero != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(startLastreDelantero.position, endLastreDelantero.position);
        //}

        //if (startSoporteSUP != null && endSoporteSUP != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(startSoporteSUP.position, endSoporteSUP.position);
        //}
        //if (startSoporteINF != null && endSoporteINF != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(startSoporteINF.position, endSoporteINF.position);
        //}
        //if (momentosSTPos != null && momentoNegativoEND != null && momentoPositivoEND != null && momentosSTNeg != null)
        //{
        //    Gizmos.color = Color.red;
        //    Gizmos.DrawLine(momentosSTNeg.position, momentoNegativoEND.position);
        //    Gizmos.color = Color.blue;
        //    Gizmos.DrawLine(momentosSTPos.position, momentoPositivoEND.position);
        //}
        //if (centroDeMomentos != null)
        //{
        //    Gizmos.color = Color.blue;
        //    Gizmos.DrawWireSphere(centroDeMomentos.position, 0.05f);
        //}
        #endregion
    }
}
