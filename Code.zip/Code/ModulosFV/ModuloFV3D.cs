using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModuloFV3D : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void updateInclinacion(float incl)
    {
        transform.localEulerAngles = new Vector3(-incl, transform.rotation.eulerAngles.y, transform.rotation.eulerAngles.z);
    }
}
