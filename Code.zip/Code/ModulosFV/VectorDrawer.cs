using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VectorDrawer : MonoBehaviour
{
    public GameObject vectorObj;
    public Transform vector_Pos;
    public float scale_Val;
    public float val;
    public GameObject objV;
    public Vector3 rotation;
    public Vector3 offSet;
    public ModulosFV3DManager modulosFVManager;
    float scaler;
    float logscaler;
    Transform vectorParent;
    // Start is called before the first frame update
    void Start()
    {

        val = val * 9.81f;
        vectorParent = GameObject.FindGameObjectWithTag("VectorParent").transform;
        modulosFVManager = FindObjectOfType<ModulosFV3DManager>();
        logscaler = Mathf.Log(val/modulosFVManager.limitLog + 1);
        scaler = modulosFVManager.escalador_Vector;
        scale_Val = val * scaler;
        objV = Instantiate(vectorObj, vector_Pos);
        objV.transform.parent = vectorParent;
        objV.transform.position = vector_Pos.position + offSet;
        objV.transform.localEulerAngles = new Vector3(rotation.x, rotation.y, rotation.z);
        objV.transform.localScale = new Vector3(scale_Val,scale_Val,scale_Val);
    }

    // Update is called once per frame
    void Update()
    {
        logscaler = Mathf.Log(val / modulosFVManager.limitLog + 1);
        scaler = modulosFVManager.escalador_Vector;
        scale_Val = val * scaler;
        objV.transform.position = vector_Pos.position + offSet;
        objV.transform.localEulerAngles = new Vector3(rotation.x, rotation.y, rotation.z);
        objV.transform.localScale = new Vector3(scale_Val, scale_Val, scale_Val);
    }
}
