using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class FVCalc : MonoBehaviour
{
    //valores constantes a considerar

    //valores menu
    #region valores y sus Textos asociados
    public float G;
    public float TNOC;
    public float Tambt;
    public float TCelula;
    public TextMeshProUGUI TcelulaResultadostx;
    public float P_STC;
    public float Ppico;
    public float gamma;
    public TextMeshProUGUI Ppicotx;
    public float Voc_STC;
    public float Isg_STC;
    public float Vmpp_STC;
    public float Impp_STC;
    public float betaVoc;
    public float betaVmpp;
    public float Voc;
    public float Vmpp;
    public TextMeshProUGUI VocVmppResultadostx;
    public float V_Inv_max;
    public float Tc_min;
    public float Ns_max;
    public TextMeshProUGUI Ns_Resultadostx;
    public float latitud;
    public float AS_SI;
    public float AS_EQ;
    public float AS_SV;
    public TextMeshProUGUI AS_Resultadostx;
    #endregion
    public GameObject menu;
    public bool activeWindow = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    #region gestionVentanasMenu
    public void menuOnOff()
    {
        if(menu.activeSelf==true)
        {
            menu.SetActive(false);
        }else
        {
            menu.SetActive(true);
        }
    }
    public void openWindow(GameObject window)
    {
        if(activeWindow == false)
        {
            window.SetActive(true);
            activeWindow = true;
        }
    }
    public void closeWindow(GameObject window)
    {
        window.SetActive(false);
        activeWindow = false;
    }
    #endregion
    #region emplazamiento
    public void editlatitud(TMP_InputField input)
    {
        latitud = float.Parse(input.text);
        
    }
    public void calcularalturasSolares()
    {
        AS_SI = 90 - latitud - 23.45f;
        AS_EQ = 90 - latitud;
        AS_SV = 90 - latitud + 23.45f;
        AS_Resultadostx.text = "SI: " + AS_SI.ToString()+"�\n" + "EQ: " + AS_EQ.ToString() + "�\n" + "SV: " + AS_SV.ToString() + "�";
    }
    #endregion
    #region Tcelula
    public void editTNOC(TMP_InputField input)
    {
        TNOC = float.Parse(input.text);
       
    }
    public void editTambt(TMP_InputField input)
    {
        string userInput = input.text.Trim(); // Elimina espacios en blanco al inicio y al final

        // Evitar procesar solo un "-" o "."
        if (userInput == "-" || userInput == "." || userInput == "-.")
        {
            Debug.LogWarning("Entrada parcial detectada, esperando un n�mero completo.");
            return;
        }
        //betaVmpp = float.Parse(input.text);
        if (float.TryParse(input.text, out float result))
        {
            Tambt = result; // Actualiza el valor si la conversi�n es exitosa
            //Debug.Log($"Tc_min actualizado a: {betaVoc}");
        }
        else
        {
            Debug.LogWarning("Entrada no v�lida. Por favor, introduce un n�mero.");
        }

    }
    public void editG(TMP_InputField input)
    {
        G = float.Parse(input.text);
        
    }
    public void calcularTCelula()
    {
        TCelula = Tambt + (TNOC-20)* G / (800);
        TcelulaResultadostx.text = "Tc: " + TCelula.ToString();
    }
    #endregion
    #region ModuloCaract
    public void editP_STC(TMP_InputField input)
    {
        P_STC = float.Parse(input.text);
    }
    public void editgamma(TMP_InputField input)
    {
        gamma = float.Parse(input.text);
    }
    public void calcularPpico()
    {
        Ppico = P_STC*(G/1000)*(1-(gamma/100)*(TCelula-25));
        Ppicotx.text = Ppico.ToString() + "Wp";
    }
    public void editVoc_STC(TMP_InputField input)
    {
        Voc_STC = float.Parse(input.text);
    }
    public void editIsg_STC(TMP_InputField input)
    {
        Isg_STC = float.Parse(input.text);
    }
    public void editVmpp_STC(TMP_InputField input)
    {
        Vmpp_STC = float.Parse(input.text);
    }
    public void editImpp_STC(TMP_InputField input)
    {
        Impp_STC = float.Parse(input.text);
    }
    public void editbetaVoc(TMP_InputField input)
    {
        string userInput = input.text.Trim(); // Elimina espacios en blanco al inicio y al final

        // Evitar procesar solo un "-" o "."
        if (userInput == "-" || userInput == "." || userInput == "-.")
        {
            Debug.LogWarning("Entrada parcial detectada, esperando un n�mero completo.");
            return;
        }
        //betaVmpp = float.Parse(input.text);
        if (float.TryParse(input.text, out float result))
        {
            betaVoc = result; // Actualiza el valor si la conversi�n es exitosa
            //Debug.Log($"Tc_min actualizado a: {betaVoc}");
        }
        else
        {
            Debug.LogWarning("Entrada no v�lida. Por favor, introduce un n�mero.");
        }
    }
    public void editbetaVmpp(TMP_InputField input)
    {
        string userInput = input.text.Trim(); // Elimina espacios en blanco al inicio y al final

        // Evitar procesar solo un "-" o "."
        if (userInput == "-" || userInput == "." || userInput == "-.")
        {
            Debug.LogWarning("Entrada parcial detectada, esperando un n�mero completo.");
            return;
        }
        //betaVmpp = float.Parse(input.text);
        if (float.TryParse(input.text, out float result))
        {
            betaVmpp = result; // Actualiza el valor si la conversi�n es exitosa
            Debug.Log($"Tc_min actualizado a: {betaVmpp}");
        }
        else
        {
            Debug.LogWarning("Entrada no v�lida. Por favor, introduce un n�mero.");
        }
    }
    public void calcularVocYVmpp()
    {
        Voc = Voc_STC + (betaVoc * Voc_STC / 100) * (TCelula-25);
        
        Vmpp = Vmpp_STC + (betaVmpp * Vmpp_STC / 100) * (TCelula - 25);
        VocVmppResultadostx.text = "Voc: "+ Voc.ToString() +"V\n"+ "Vmpp: "+ Vmpp.ToString() + "V";
    }
    #endregion
    #region Limites inversor
    public void editV_Inv_max(TMP_InputField input)
    {
        V_Inv_max = float.Parse(input.text);
    }
    public void editTc_min(TMP_InputField input)
    {
        string userInput = input.text.Trim(); // Elimina espacios en blanco al inicio y al final

        // Evitar procesar solo un "-" o "."
        if (userInput == "-" || userInput == "." || userInput == "-.")
        {
            Debug.LogWarning("Entrada parcial detectada, esperando un n�mero completo.");
            return;
        }
        //betaVmpp = float.Parse(input.text);
        if (float.TryParse(input.text, out float result))
        {
            Tc_min = result; // Actualiza el valor si la conversi�n es exitosa
        }
        else
        {
            Debug.LogWarning("Entrada no v�lida. Por favor, introduce un n�mero.");
        }
    }
    public void calcularNs_max()
    {
        float Voc_max = Voc_STC + (betaVoc * Voc_STC / 100) * (Tc_min - 25);
        float aux;
        Ns_max = V_Inv_max / Voc_max;
        aux = Ns_max;
        int Ns_i = Mathf.FloorToInt(Ns_max);
        Ns_max = Ns_i;
        Ns_Resultadostx.text = "Ns_max: " + Ns_i.ToString() + " M�dulos/serie\n" + "Voc_max(Tmin): " + Voc_max.ToString() + " �C";
    }
    #endregion

}
