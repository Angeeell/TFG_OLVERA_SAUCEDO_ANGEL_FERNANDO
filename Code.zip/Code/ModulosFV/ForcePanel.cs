using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;

public class ForcePanel : MonoBehaviour
{
    public Rigidbody rb;
    public float force;
    public Vector3 forceVect;
    public Transform centroPresiones;
    public bool applyforce;
    public VectorDrawer VectorDrawer;
    public bool hasVectorDrawer;
    // Start is called before the first frame update
    void Start()
    {
        if(hasVectorDrawer == true && applyforce == true)
        {
            VectorDrawer.val = force;
        }
        if (hasVectorDrawer == true && applyforce == false)
        {
            VectorDrawer.val = 0;
        }

    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        if(applyforce==true)
        {
            forceVect = new Vector3(0, 0, -force);
            rb.AddForceAtPosition(forceVect, centroPresiones.position);
            
        }
       
    }
    void Update()
    {
        if (hasVectorDrawer == true && applyforce == true)
        {
            VectorDrawer.val = force;
        }
        if (hasVectorDrawer == true && applyforce == false)
        {
            VectorDrawer.val = 0;
        }

    }
 
}
