using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using TMPro;
using System.IO;
using System.Globalization;

public class LightController : MonoBehaviour
{
    public Transform sun;
    public int stated;
    public bool simulateSun=false;
    public bool simulateByStepSun = false;
    public bool activeSimulation = false;
    public float timeDataFlow;
    public int arrayEv;
    public int arrayAc;
    public int arrayDt;
    public int dato=0;
    public TextMeshProUGUI elevacionTx;
    public TextMeshProUGUI acimutTx;
    public TextMeshProUGUI horaTx;
    public TextMeshProUGUI simTx;
    //0--SI
    public List<float> alturaSolar_SI = new List<float>();
    public List<float> azimut_SI = new List<float>();
    public List<string> hora_SI = new List<string>();
    //1--EQ
    public List<float> alturaSolar_EQ = new List<float>();
    public List<float> azimut_EQ = new List<float>();
    public List<string> hora_EQ = new List<string>();
    //2--SV
    public List<float> alturaSolar_SV = new List<float>();
    public List<float> azimut_SV = new List<float>();
    public List<string> hora_SV = new List<string>();

    // Start is called before the first frame update
    void Start()
    {
        //caso de SI
        #region SUNPOS_DATA_SI
        string filePath_SI = Application.dataPath + "/Data/Pos_Sun_SI.csv";

        if (File.Exists(filePath_SI))
        {
            string[] lines = File.ReadAllLines(filePath_SI);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float elevacion;
                    float azimut;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool elevOk = float.TryParse(values[1], NumberStyles.Float, culture, out elevacion);
                    bool azimOk = float.TryParse(values[2], NumberStyles.Float, culture, out azimut);

                    if (elevOk && azimOk)
                    {
                        hora_SI.Add(hora);
                        alturaSolar_SI.Add(elevacion);
                        azimut_SI.Add(azimut);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < hora_SI.Count; i++)
            {
                //Debug.Log($"Hora: {hora_SI[i]} - Elevaci�n: {alturaSolar_SI[i]} - Azimut: {azimut_SI[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + filePath_SI);
        }
        #endregion
        #region SUNPOS_DATA_EQ
        string filePath_EQ = Application.dataPath + "/Data/Pos_Sun_EQ.csv";

        if (File.Exists(filePath_EQ))
        {
            string[] lines = File.ReadAllLines(filePath_EQ);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float elevacion;
                    float azimut;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool elevOk = float.TryParse(values[1], NumberStyles.Float, culture, out elevacion);
                    bool azimOk = float.TryParse(values[2], NumberStyles.Float, culture, out azimut);

                    if (elevOk && azimOk)
                    {
                        hora_EQ.Add(hora);
                        alturaSolar_EQ.Add(elevacion);
                        azimut_EQ.Add(azimut);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < hora_EQ.Count; i++)
            {
                //Debug.Log($"Hora: {hora_EQ[i]} - Elevaci�n: {alturaSolar_EQ[i]} - Azimut: {azimut_EQ[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + filePath_EQ);
        }
        #endregion
        #region SUNPOS_DATA_SV
        string filePath_SV = Application.dataPath + "/Data/Pos_Sun_SV.csv";

        if (File.Exists(filePath_SV))
        {
            string[] lines = File.ReadAllLines(filePath_SV);
            CultureInfo culture = CultureInfo.InvariantCulture; // Asegura que el punto (.) sea decimal

            // Saltamos la cabecera
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] values = line.Split(';'); // Cambiado a punto y coma

                if (values.Length >= 3)
                {
                    string hora = values[0];
                    float elevacion;
                    float azimut;

                    // Intentamos convertir Elevacion y Azimut a float con formato seguro
                    bool elevOk = float.TryParse(values[1], NumberStyles.Float, culture, out elevacion);
                    bool azimOk = float.TryParse(values[2], NumberStyles.Float, culture, out azimut);

                    if (elevOk && azimOk)
                    {
                        hora_SV.Add(hora);
                        alturaSolar_SV.Add(elevacion);
                        azimut_SV.Add(azimut);
                    }
                    else
                    {
                        Debug.LogWarning($"Error de conversi�n num�rica en l�nea {i + 1}: '{values[1]}', '{values[2]}'");
                    }
                }
                else
                {
                    Debug.LogWarning($"L�nea {i + 1} no tiene suficientes valores.");
                }
            }

            // Verificaci�n de que los datos se cargaron correctamente
            for (int i = 0; i < hora_SV.Count; i++)
            {
                //Debug.Log($"Hora: {hora_SV[i]} - Elevaci�n: {alturaSolar_SV[i]} - Azimut: {azimut_SV[i]}");
            }
        }
        else
        {
            Debug.LogError("Archivo CSV no encontrado en: " + filePath_SV);
        }
        #endregion
    }

    // Update is called once per frame
    void Update()
    {
        if(stated == 0)//SI
        {
            #region casoSI
            arrayEv = alturaSolar_SI.Count;
            arrayAc = azimut_SI.Count;
            arrayDt = hora_SI.Count;
            if(simulateSun==true)//simulacion tiempo seguido
            {
               activeSimulation = true;
             StartCoroutine(sunTimer(stated, arrayEv));
                simTx.text = "SI";
                simulateSun = false;
            }
            if(simulateByStepSun==true)//simulacion por pasos
            {
                simTx.text = "SI";
                if (Input.GetKeyDown(KeyCode.R)&&dato>0)//ir una hacia atr�s
                {
                    dato -= 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SI[dato], azimut_SI[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_SI[dato].ToString();
                    acimutTx.text = azimut_SI[dato].ToString();
                    horaTx.text = hora_SI[dato].ToString();
                }
                else if(Input.GetKeyDown(KeyCode.T)&&dato<(arrayEv-1))//ir una hacia delante
                {
                    dato += 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SI[dato], azimut_SI[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_SI[dato].ToString();
                    acimutTx.text = azimut_SI[dato].ToString();
                    horaTx.text = hora_SI[dato].ToString();
                }
            }
            #endregion
        }
        else if(stated == 1)//EQ
        {
            #region casoEQ
            arrayEv = alturaSolar_EQ.Count;
            arrayAc = azimut_EQ.Count;
            arrayDt = hora_EQ.Count;
            if (simulateSun == true)
            {
                activeSimulation = true;
                StartCoroutine(sunTimer(stated, arrayEv));
                simTx.text = "EQ";
                simulateSun = false;
            }
            if (simulateByStepSun == true)//simulacion por pasos
            {
                simTx.text = "EQ";
                if (Input.GetKeyDown(KeyCode.R) && dato > 0)//ir una hacia atr�s
                {
                    dato -= 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_EQ[dato], azimut_EQ[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_EQ[dato].ToString();
                    acimutTx.text = azimut_EQ[dato].ToString();
                    horaTx.text = hora_EQ[dato].ToString();
                }
                else if (Input.GetKeyDown(KeyCode.T) && dato < (arrayEv - 1))//ir una hacia delante
                {
                    dato += 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_EQ[dato], azimut_EQ[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_EQ[dato].ToString();
                    acimutTx.text = azimut_EQ[dato].ToString();
                    horaTx.text = hora_EQ[dato].ToString();
                }
            }
            #endregion
        }
        else if (stated == 2)//SV
        {
            #region casoSV
            arrayEv = alturaSolar_SV.Count;
            arrayAc = azimut_SV.Count;
            arrayDt = hora_SV.Count;
            if (simulateSun == true)
            {
                activeSimulation = true;
                StartCoroutine(sunTimer(stated, arrayEv));
                simTx.text = "SV";
                simulateSun = false;
            }
            if (simulateByStepSun == true)//simulacion por pasos
            {
                simTx.text = "SV";
                if (Input.GetKeyDown(KeyCode.R) && dato > 0)//ir una hacia atr�s
                {
                    dato -= 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SV[dato], azimut_SV[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_SV[dato].ToString();
                    acimutTx.text = azimut_SV[dato].ToString();
                    horaTx.text = hora_SV[dato].ToString();
                }
                else if (Input.GetKeyDown(KeyCode.T) && dato < (arrayEv - 1))//ir una hacia delante
                {
                    dato += 1;
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SV[dato], azimut_SV[dato] + 180, 0);
                    elevacionTx.text = alturaSolar_SV[dato].ToString();
                    acimutTx.text = azimut_SV[dato].ToString();
                    horaTx.text = hora_SV[dato].ToString();
                }
            }
            #endregion
        }


    }

    IEnumerator sunTimer(int state, int array)
    {
        
            for (int i = 0; i < array; i++)
            {
                if(activeSimulation == false)
                {
                    state = -1;
                }
                if (state == 0)//SI
                {
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SI[i], azimut_SI[i] + 180, 0);
                    elevacionTx.text = alturaSolar_SI[i].ToString();
                    acimutTx.text = azimut_SI[i].ToString();
                    horaTx.text = hora_SI[i].ToString();
                    yield return new WaitForSeconds(timeDataFlow);
                }
                else if (state == 1)//EQ
                {
                    sun.transform.eulerAngles = new Vector3(alturaSolar_EQ[i], azimut_EQ[i] + 180, 0);
                    elevacionTx.text = alturaSolar_EQ[i].ToString();
                    acimutTx.text = azimut_EQ[i].ToString();
                    horaTx.text = hora_EQ[i].ToString();
                    yield return new WaitForSeconds(timeDataFlow);
                }
                else if (state == 2)//SV
                {
                    sun.transform.eulerAngles = new Vector3(alturaSolar_SV[i], azimut_SV[i] + 180, 0);
                    elevacionTx.text = alturaSolar_SV[i].ToString();
                    acimutTx.text = azimut_SV[i].ToString();
                    horaTx.text = hora_SV[i].ToString();
                    yield return new WaitForSeconds(timeDataFlow);
                }
            
            }
            stated -= 1;
            simulateSun = true;
            if (stated <= -1)
            {
                sun.transform.eulerAngles = new Vector3(30f, 180 + 180, 0);
                activeSimulation = false;
                simulateSun = false;
            }
        
        
        
    }

    public void simulate()
    {
        if(activeSimulation==false)
        {
            if(simulateByStepSun == true)
            {
                simulateByStepSun = false;
            }
            stated = 2;
            simulateSun = true;
        }
        
    }

    public void simulateByStep()
    {
       
        if(activeSimulation==false)
        {
            simulateByStepSun = true;
            activeSimulation = true;
        }
       
    }
    public void endSimulateByStep()
    {//tambien para la simulacion de sombras continuada
        simulateByStepSun =false;
        activeSimulation = false;
        sun.transform.eulerAngles = new Vector3(30f, 180 + 180, 0);
        stated = -1;
    }
    public void changeStatedStep(int state)
    {
        if(simulateByStepSun == true)
        {
            dato = 0;
            stated = state;
        }
        
    }
}
